﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;

    public int Coin = 0;
    public int Goal = 4;
    public Text txt_Coins;
    public string CurrentScene = "Level 1";


    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (CurrentScene == "Level 1" && Coin >= Goal)
        {
            SceneManager.LoadScene("Level 2");
            Coin = 0;
        }
        else if(CurrentScene != "Level 1" && Coin >= Goal)
        {
            SceneManager.LoadScene("GameWin");
        }
    }

    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
    }

    public void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Coins")
        {
            Destroy(other.gameObject);
            Coin++;
            txt_Coins.text = "Coins Collected = " + Coin;
        }

        if(other.tag == "Hazzard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}